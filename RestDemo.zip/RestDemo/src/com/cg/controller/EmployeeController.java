package com.cg.controller;

import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;



@Path("/employee")
public class EmployeeController
{
	@GET
	@Path("/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	/*public String sayHello(@PathParam("id") int id )
	{
		return("<h1> Hello from REST WS GET ID ="+id+"</h1>");
	}
	*/
	public Employee findEmployeeById(@PathParam("id") int id )
	{
		Employee emp = new Employee(id,"John",9000);
		return emp;
	}
		
	@POST
	@Produces(MediaType.TEXT_HTML)
	public String sayHello1(@FormParam("empid") int id)
	{
		return("<h1> Hello from REST WS POST ID ="+id+"</h1>");
	}
		
	
}
