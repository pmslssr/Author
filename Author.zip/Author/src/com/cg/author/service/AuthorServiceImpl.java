package com.cg.author.service;

import java.util.List;

import com.cg.author.dao.AuthorDaoImpl;
import com.cg.author.dao.IAuthorDao;
import com.cg.author.dto.Author;

public class AuthorServiceImpl implements IAuthorService {

	private IAuthorDao authorDao;

	public AuthorServiceImpl() {
		authorDao = new AuthorDaoImpl();
	}

	@Override
	public int addAuthor(Author author) {
		// For Adding

		int id = authorDao.addAuthor(author);
		return id;
	}

	@Override
	public void updateAuthor(Author author) {
		authorDao.updateAuthor(author);

	}

	@Override
	public void deleteAuthor(Author author) {

		authorDao.deleteAuthor(author);

	}

	@Override
	public List<Author> viewAllAuthors() {
		// For Listing
		List<Author> list = authorDao.viewAllAuthors();
		return list;
	}

	@Override
	public Author getAuthorById(int id) {
		Author author = authorDao.getAuthorById(id);
		return author;
	}

}
