package com.cg.author.service;

import java.util.List;

import com.cg.author.dto.Author;

public interface IAuthorService {
	public int addAuthor(Author author);

	public abstract void updateAuthor(Author author);

	public abstract void deleteAuthor(Author author);
	public List<Author> viewAllAuthors();

	public abstract Author getAuthorById(int id);
}
