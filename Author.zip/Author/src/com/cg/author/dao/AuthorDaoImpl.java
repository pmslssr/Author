package com.cg.author.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.cg.author.dto.Author;
import com.cg.author.util.JPAUtil;

public class AuthorDaoImpl implements IAuthorDao {

	private EntityManager entityManager;

	public AuthorDaoImpl() {
		entityManager = JPAUtil.getEntityManager();
	}

	@Override
	public int addAuthor(Author author) {
		// For Adding
		entityManager.getTransaction().begin();
		entityManager.persist(author);
		entityManager.getTransaction().commit();
		return (author.getAuthorId());

	}

	@Override
	public void updateAuthor(Author author) {

		entityManager.getTransaction().begin();
		entityManager.merge(author);
		entityManager.getTransaction().commit();

	}

	@Override
	public void deleteAuthor(Author author) {
		entityManager.getTransaction().begin();
		entityManager.remove(author);

		entityManager.getTransaction().commit();
	}

	@Override
	public List<Author> viewAllAuthors() {
		// For listing Products
		TypedQuery<Author> qry = entityManager.createQuery("from Author",
				Author.class);
		List<Author> list = qry.getResultList();
		return list;
	}

	@Override
	public Author getAuthorById(int id) {
		Author author = entityManager.find(Author.class, id);
		return author;
	}

}
