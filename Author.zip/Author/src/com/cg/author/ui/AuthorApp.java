package com.cg.author.ui;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.author.dto.Author;
import com.cg.author.service.AuthorServiceImpl;
import com.cg.author.service.IAuthorService;

public class AuthorApp {

	public static void main(String[] args) {

		Scanner scr = new Scanner(System.in);
		IAuthorService service = new AuthorServiceImpl();
		int choice = 1;
		while (choice != 5) {
			System.out.println("1. Add Author ");
			System.out.println("2. List All Authors ");
			System.out.println("3. Delete Author ");
			System.out.println("4. Update Author ");
			System.out.println("5. Exit ");
			System.out.println("Ente Your Choice ");
			choice = scr.nextInt();
			switch (choice) {
			case 1:
				System.out.println("Enter Author First Name");
				String fname = scr.next();
				System.out.println("Enter Author Second Name");
				String mname = scr.next();
				System.out.println("Enter Author Last Name");
				String lname = scr.next();
				System.out.println("Enter the Mobile Number");
				String phoneNo = scr.next();

				Author author = new Author();
				author.setFirstName(fname);
				author.setMiddleName(mname);
				author.setLastName(lname);
				author.setPhoneNo(phoneNo);

				int pid = service.addAuthor(author);
				System.out.println("Author Added Successfully");
				System.out.println("Author  Id  " + pid);
				break;

			case 2:
				List<Author> list = service.viewAllAuthors();
				if (list.isEmpty()) {
					System.out.println("No Authors Available");
				} else {
					for (Author a : list) {
						System.out.println(a.getAuthorId() + " "
								+ a.getFirstName() + " " + a.getMiddleName()
								+ " " + a.getLastName() + " " + a.getPhoneNo());
					}
				}
				break;

			case 3:
				System.out.println("Enter the Author Id you want to delete");
				int id = scr.nextInt();
				author = service.getAuthorById(id);
				service.deleteAuthor(author);
				System.out.println(" Deleted Author " + author.getAuthorId());
				break;
			case 4:
				System.out.println("Enter the Author Id you want to update");
				int id1 = scr.nextInt();
				int choice1 = 1;

				while (choice1 !=5 ) {
					System.out.println("1.For First Name");
					System.out.println("2.For Middle Name");
					System.out.println("3.For Last Name");
					System.out.println("4.For Phone Number");
					System.out.println("Ente Your Choice ");
					choice = scr.nextInt();
					switch (choice) {
					case 1:
						System.out.println("Enter the New First Name ");
						String str = scr.next();
						author = service.getAuthorById(id1);
						author.setFirstName(str);
						
						System.out.println(" Updated  Author First Name Successfully "+ author.getAuthorId());
		
						break;
					case 2:
						System.out.println("Enter the New Middle Name");
						String str1 = scr.next();
						author = service.getAuthorById(id1);
						author.setMiddleName(str1);
						System.out.println(" Updated  Author Middle Name Successfully "+ author.getAuthorId());
						break;
					case 3:
						System.out.println("Enter the New Last Name");
						String str2 = scr.next();
						author = service.getAuthorById(id1);
						author.setLastName(str2);
						System.out.println(" Updated  Author Last Name Successfully "+ author.getAuthorId());
						break;
					case 4:
						EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
						EntityManager em=emf.createEntityManager();
						System.out.println("Enter the New Phone Name");
						String str3 = scr.next();
						author = service.getAuthorById(id1);
						author.setPhoneNo(str3);
						Author e =em.find(Author.class, id1);
						e.setPhoneNo(str3);
						System.out.println(" Updated  Author Phone Number Successfully "+ author.getAuthorId());
						break;
						

					}
				}
				break;
			case 5:
				System.out.println("Thank You!");

			}
		}
	}

}
