CREATE TABLE author_tbl(author_id NUMBER(6) PRIMARY KEY, 
first_name  VARCHAR2(15),
middle_name VARCHAR2(15),
last_name VARCHAR2(15),
phone_no VARCHAR2(10));